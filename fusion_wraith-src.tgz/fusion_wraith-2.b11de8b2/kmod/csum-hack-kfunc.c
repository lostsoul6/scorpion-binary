#include <linux/bpf.h>
#include <linux/btf.h>
#include <linux/btf_ids.h>
#include <linux/kprobes.h>
#include <linux/skbuff.h>
#include <linux/tcp.h>
#include <linux/udp.h>

#include "csum-hack.h"

#ifndef __bpf_kfunc
#define __bpf_kfunc __used noinline
#endif

#ifndef __bpf_kfunc_start_defs
#define __bpf_kfunc_start_defs()                                          \
  __diag_push();                                                          \
  __diag_ignore_all("-Wmissing-declarations",                             \
                    "Global kfuncs as their definitions will be in BTF"); \
  __diag_ignore_all("-Wmissing-prototypes", "Global kfuncs as their definitions will be in BTF")
#endif

#ifndef __bpf_kfunc_end_defs
#define __bpf_kfunc_end_defs() __diag_pop()
#endif

#ifndef BTF_KFUNCS_START
#define BTF_KFUNCS_START BTF_SET8_START
#endif

#ifndef BTF_KFUNCS_END
#define BTF_KFUNCS_END BTF_SET8_END
#endif

__bpf_kfunc_start_defs();

// Inspect kernel representation of a BPF `__sk_buff`.
//
// Newer versions of Linux has `bpf_cast_to_kern_ctx` kfunc. This function is meant to provide such
// functionality for lower versions of kernel.
__bpf_kfunc struct sk_buff* fusion_wraith_inspect_skb(struct __sk_buff* skb_bpf) {
  return (struct sk_buff*)skb_bpf;
}

// Change checksum position in `sk_buff` to instruct hardware/driver/kernel to offset checksum
// correctly.
__bpf_kfunc int fusion_wraith_change_csum_offset(struct __sk_buff* skb_bpf, __u16 new_proto) {
  return change_csum_offset((struct sk_buff*)skb_bpf, new_proto);
}

// After the BPF program opened room after the IP header and wrote a TCP header
// there, bring the skb's own idea of its headers in line: header offsets, the
// checksum position and, for a UDP segmentation-offload burst, the segmentation
// type. The stack then splits a burst into TCP segments, one per datagram, each
// with its own sequence number.
//
// The BPF program cannot do this itself: gso_type and the header offsets are
// not reachable from BPF. Everything is checked; nothing here trusts the caller.
__bpf_kfunc int fusion_wraith_udp_to_tcp(struct __sk_buff* skb_bpf, __u32 l3_off, __u32 l4_off,
                                       __u16 ipv6) {
  struct sk_buff* skb = (struct sk_buff*)skb_bpf;
  struct skb_shared_info* shinfo = skb_shinfo(skb);
  if (skb->encapsulation) return -EINVAL;
  if (l3_off >= l4_off || l4_off + sizeof(struct tcphdr) > skb_headlen(skb)) return -EINVAL;
  if (skb_is_gso(skb)) {
    if (!(shinfo->gso_type & SKB_GSO_UDP_L4) || skb->ip_summed != CHECKSUM_PARTIAL) return -EINVAL;
    shinfo->gso_type =
      (shinfo->gso_type & ~SKB_GSO_UDP_L4) | (ipv6 ? SKB_GSO_TCPV6 : SKB_GSO_TCPV4);
  }
  // Adding room moved the data and the headers in front of it, but not the
  // header offsets the stack keeps.
  skb_reset_mac_header(skb);
  skb_set_network_header(skb, l3_off);
  skb_set_transport_header(skb, l4_off);
  if (skb->ip_summed == CHECKSUM_PARTIAL) {
    skb->csum_start = skb_transport_header(skb) - skb->head;
    skb->csum_offset = offsetof(struct tcphdr, check);
  }
  return 0;
}

// The receive-side mirror: after the BPF program shrank the headers and wrote a
// UDP header, bring the skb in line. A segment the kernel merged (GRO) is a TCP
// segmentation-offload skb; it becomes a UDP one with the same segment size, so
// the socket sees the datagrams it was sent (UDP_GRO), or the stack splits them
// again for a socket that did not ask for coalescing.
__bpf_kfunc int fusion_wraith_tcp_to_udp(struct __sk_buff* skb_bpf, __u32 l3_off, __u32 l4_off,
                                       __u16 ipv6) {
  struct sk_buff* skb = (struct sk_buff*)skb_bpf;
  struct skb_shared_info* shinfo = skb_shinfo(skb);
  const unsigned int tcp_types =
    SKB_GSO_TCPV4 | SKB_GSO_TCPV6 | SKB_GSO_TCP_ECN | SKB_GSO_TCP_FIXEDID;
  if (skb->encapsulation) return -EINVAL;
  if (l3_off >= l4_off || l4_off + sizeof(struct udphdr) > skb_headlen(skb)) return -EINVAL;
  if (skb_is_gso(skb)) {
    if (!(shinfo->gso_type & (SKB_GSO_TCPV4 | SKB_GSO_TCPV6)) || skb->ip_summed != CHECKSUM_PARTIAL)
      return -EINVAL;
    shinfo->gso_type = (shinfo->gso_type & ~tcp_types) | SKB_GSO_UDP_L4;
  }
  skb_reset_mac_header(skb);
  skb_set_network_header(skb, l3_off);
  skb_set_transport_header(skb, l4_off);
  if (skb->ip_summed == CHECKSUM_PARTIAL) {
    skb->csum_start = skb_transport_header(skb) - skb->head;
    skb->csum_offset = offsetof(struct udphdr, check);
  }
  return 0;
}

__bpf_kfunc_end_defs();

BTF_KFUNCS_START(fusion_wraith_tc_set)
BTF_ID_FLAGS(func, fusion_wraith_inspect_skb)
BTF_ID_FLAGS(func, fusion_wraith_change_csum_offset)
BTF_ID_FLAGS(func, fusion_wraith_udp_to_tcp)
BTF_ID_FLAGS(func, fusion_wraith_tcp_to_udp)
BTF_KFUNCS_END(fusion_wraith_tc_set)

static const struct btf_kfunc_id_set fusion_wraith_tc_kfunc_set = {
  .owner = THIS_MODULE,
  .set = &fusion_wraith_tc_set,
};

int csum_hack_init(void) {
  return register_btf_kfunc_id_set(BPF_PROG_TYPE_SCHED_CLS, &fusion_wraith_tc_kfunc_set);
}

void csum_hack_exit(void) {}
