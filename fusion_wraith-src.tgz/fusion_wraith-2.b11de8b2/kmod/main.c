#include <linux/module.h>

#include "csum-hack.h"

MODULE_VERSION("0.7.1");
MODULE_DESCRIPTION("eBPF TCP -> UDP obfuscator - kernel module extension");
MODULE_LICENSE("GPL");

static int __init fusion_wraith_init(void) {
  int ret = csum_hack_init();
  return ret;
}

static void __exit fusion_wraith_exit(void) { csum_hack_exit(); }

module_init(fusion_wraith_init);
module_exit(fusion_wraith_exit);
